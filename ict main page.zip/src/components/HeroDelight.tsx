import { useRef, useEffect, useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import type { LucideIcon } from "lucide-react";
import { usePerfMode } from "@/hooks/use-perf-mode";

type Orb = { id: number; size: number; x: number; y: number; delay: number; duration: number };

type OrbitBadge = {
  id: number;
  label: string;
  icon: LucideIcon;
  href: string;
  angle: number;
  radius: string;
  duration: string;
};

function generateOrbs(count: number): Orb[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    size: 2 + Math.random() * 4,
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * -10,
    duration: 5 + Math.random() * 7,
  }));
}

export function HeroDelight({
  badges,
  lite,
}: {
  badges: OrbitBadge[];
  lite: boolean;
}) {
  const prefersReduced = useReducedMotion();
  const reduce = prefersReduced || lite;
  const [orbs, setOrbs] = useState<Orb[]>([]);
  const seeded = useRef(false);

  useEffect(() => {
    if (seeded.current) return;
    seeded.current = true;
    setOrbs(generateOrbs(18));
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {!reduce &&
        orbs.map((orb) => (
          <span
            key={orb.id}
            className="absolute rounded-full bg-crystal-glow/60 animate-float-orb"
            style={{
              width: orb.size,
              height: orb.size,
              left: `${orb.x}%`,
              top: `${orb.y}%`,
              animationDelay: `${orb.delay}s`,
              animationDuration: `${orb.duration}s`,
            }}
          />
        ))}

      {!reduce &&
        badges.map((badge) => {
          const Icon = badge.icon;
          return (
            <a
              key={badge.id}
              href={badge.href}
              className="pointer-events-auto absolute left-1/2 top-1/2 hidden -translate-x-1/2 -translate-y-1/2 items-center gap-1.5 rounded-full border border-border bg-card/60 px-2.5 py-1 text-[10px] text-foreground/90 backdrop-blur-md transition-transform hover:scale-105 hover:text-primary md:inline-flex"
              style={{
                // @ts-ignore CSS custom property
                "--orbit-radius": badge.radius,
                "--orbit-duration": badge.duration,
                animation: `orbit ${badge.duration} linear infinite`,
                animationDelay: `${-parseFloat(badge.duration) * (badge.angle / 360)}s`,
              }}
            >
              <Icon className="h-3 w-3" />
              <span className="font-mono">{badge.label}</span>
            </a>
          );
        })}
    </div>
  );
}

export function HeroEntrance({
  children,
  delay = 0,
  lite,
}: {
  children: React.ReactNode;
  delay?: number;
  lite: boolean;
}) {
  const prefersReduced = useReducedMotion();
  const reduce = prefersReduced || lite;
  if (reduce) return <>{children}</>;
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}
