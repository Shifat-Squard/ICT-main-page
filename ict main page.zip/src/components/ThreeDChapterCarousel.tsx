import { useCallback, useEffect, useRef, useState } from "react";
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  animate,
  useReducedMotion,
  type MotionValue,
} from "motion/react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { CarouselChapter } from "@/types/chapter";
import { ChapterCard3D } from "@/components/ChapterCard3D";
import { useIsMobile } from "@/hooks/use-mobile";
import { usePerfMode, useRafThrottle } from "@/hooks/use-perf-mode";

type ThreeDChapterCarouselProps = {
  chapters: CarouselChapter[];
  /** progress percentage per chapter id */
  progressById?: Record<number, number>;
  onSelect?: (chapter: CarouselChapter) => void;
};

function CarouselItem({
  chapter,
  index,
  step,
  radius,
  rotation,
  progress,
  isActive,
  lite,
  onClick,
}: {
  chapter: CarouselChapter;
  index: number;
  step: number;
  radius: number;
  rotation: MotionValue<number>;
  progress: number;
  isActive: boolean;
  lite: boolean;
  onClick: () => void;
}) {
  const angle = useTransform(rotation, (r) => ((r + index * step) % 360 + 360) % 360);
  const depth = useTransform(angle, (a) => Math.cos((a * Math.PI) / 180));
  const opacity = useTransform(depth, [-1, 0, 1], [0.15, 0.5, 1]);
  const scale = useTransform(depth, [-1, 1], [0.82, 1]);
  const blur = useTransform(depth, [-1, 1], [4, 0]);
  // Per-frame blur is the most expensive depth cue — drop it on low-end devices.
  // Per-frame blur is the priciest depth cue; lite mode keeps a static value so the
  // layout/flattening stays identical without recomputing a filter every frame.
  const filter = useTransform(blur, (b) => (lite ? "blur(0px)" : `blur(${b.toFixed(2)}px)`));

  return (
    <div
      className="absolute left-1/2 top-1/2"
      style={{
        width: radius < 300 ? 240 : 280,
        height: 380,
        marginLeft: radius < 300 ? -120 : -140,
        marginTop: -190,
        transform: `rotateY(${index * step}deg) translateZ(${radius}px)`,
        transformStyle: "preserve-3d",
        pointerEvents: isActive ? "auto" : "none",
      }}
    >
      <motion.div
        className="h-full w-full"
        style={{ opacity, scale, filter, transformStyle: "preserve-3d" }}
      >
        <button
          type="button"
          onClick={onClick}
          aria-label={chapter.title}
          className="block h-full w-full cursor-pointer rounded-2xl text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          style={{ transformStyle: "preserve-3d" }}
        >
          <ChapterCard3D chapter={chapter} progress={progress} active={isActive} />
        </button>
      </motion.div>
    </div>

  );
}

export function ThreeDChapterCarousel({
  chapters,
  progressById = {},
  onSelect,
}: ThreeDChapterCarouselProps) {
  const count = chapters.length;
  const step = 360 / Math.max(count, 1);
  const isMobile = useIsMobile();
  const prefersReduced = useReducedMotion();
  const { lite } = usePerfMode();
  const reduceMotion = prefersReduced || lite;
  const radius = isMobile ? 260 : 420;

  const rotation = useMotionValue(0);
  const spring = useSpring(rotation, {
    stiffness: lite ? 140 : 90,
    damping: lite ? 26 : 20,
    mass: lite ? 0.4 : 0.6,
  });
  const [active, setActive] = useState(0);
  const [selected, setSelected] = useState<CarouselChapter | null>(null);

  const drag = useRef({ active: false, lastX: 0, velocity: 0, moved: 0, time: 0 });

  const syncActive = useCallback(
    (r: number) => {
      const i = ((Math.round(-r / step) % count) + count) % count;
      setActive(i);
    },
    [count, step],
  );

  useEffect(() => {
    syncActive(rotation.get());
    return spring.on("change", syncActive);
  }, [spring, rotation, syncActive]);

  const snapTo = useCallback(
    (target: number) => {
      const snapped = Math.round(target / step) * step;
      animate(rotation, snapped, {
        type: "spring",
        stiffness: 70,
        damping: 18,
        mass: 0.7,
      });
    },
    [rotation, step],
  );

  const goto = (dir: 1 | -1) => snapTo(rotation.get() - dir * step);

  const onPointerDown = (e: React.PointerEvent) => {
    (e.target as Element).setPointerCapture?.(e.pointerId);
    drag.current = {
      active: true,
      lastX: e.clientX,
      velocity: 0,
      moved: 0,
      time: performance.now(),
    };
  };

  // Coalesce pointermove to one update per frame (pointer events can fire 2-4x per frame).
  const onPointerMove = useRafThrottle((clientX: number) => {
    if (!drag.current.active) return;
    const dx = clientX - drag.current.lastX;
    const now = performance.now();
    const dt = Math.max(now - drag.current.time, 1);
    drag.current.lastX = clientX;
    drag.current.time = now;
    drag.current.moved += Math.abs(dx);
    drag.current.velocity = (dx / dt) * 16;
    rotation.set(rotation.get() + dx * 0.28);
  });

  const endDrag = () => {
    if (!drag.current.active) return;
    drag.current.active = false;
    const momentum = drag.current.velocity * 6;
    snapTo(rotation.get() + momentum);
  };

  const handleSelect = (chapter: CarouselChapter) => {
    if (drag.current.moved > 8) return;
    setSelected(chapter);
    onSelect?.(chapter);
  };

  const finishSelection = () => {
    if (!selected) return;
    if (selected.href) window.open(selected.href, "_blank", "noreferrer");
    setTimeout(() => setSelected(null), 220);
  };

  return (
    <div className="relative">
      <div
        role="group"
        aria-label="Chapter carousel"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight") goto(1);
          if (e.key === "ArrowLeft") goto(-1);
        }}
        onPointerDown={onPointerDown}
        onPointerMove={(e) => onPointerMove(e.clientX)}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onPointerLeave={endDrag}
        className="relative mx-auto h-[440px] w-full cursor-grab touch-pan-y select-none active:cursor-grabbing focus:outline-none md:h-[500px]"
        style={{ perspective: 1400 }}
      >
        <motion.div
          className="absolute inset-0"
          style={{
            transformStyle: "preserve-3d",
            rotateY: prefersReduced ? 0 : spring,
          }}
        >
          {chapters.map((ch, i) => (
            <CarouselItem
              key={ch.id}
              chapter={ch}
              index={i}
              step={step}
              radius={radius}
              rotation={spring}
              progress={progressById[ch.id] ?? 0}
              isActive={i === active}
              lite={lite}
              onClick={() => handleSelect(ch)}
            />
          ))}
        </motion.div>
      </div>

      <div className="mt-4 flex items-center justify-center gap-4">
        <button
          type="button"
          onClick={() => goto(-1)}
          aria-label="Previous chapter"
          className="glass-card flex h-10 w-10 items-center justify-center rounded-full text-primary transition-transform hover:scale-105"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2">
          {chapters.map((ch, i) => (
            <span
              key={ch.id}
              className={`h-1.5 rounded-full transition-all ${
                i === active ? "w-6 bg-primary" : "w-1.5 bg-muted-foreground/40"
              }`}
            />
          ))}
        </div>
        <button
          type="button"
          onClick={() => goto(1)}
          aria-label="Next chapter"
          className="glass-card flex h-10 w-10 items-center justify-center rounded-full text-primary transition-transform hover:scale-105"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      <AnimatePresence>
        {selected && (
          <motion.div
            className={`fixed inset-0 z-50 flex items-center justify-center bg-background/80 ${
              lite ? "" : "backdrop-blur-md"
            }`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelected(null)}
          >
            <motion.div
              className="w-[300px] md:w-[340px]"
              style={{ height: 420 }}
              initial={reduceMotion ? { opacity: 0 } : { scale: 0.7, opacity: 0, rotateY: -18 }}
              animate={reduceMotion ? { opacity: 1 } : { scale: 1, opacity: 1, rotateY: 0 }}
              exit={reduceMotion ? { opacity: 0 } : { scale: 0.85, opacity: 0 }}
              transition={
                reduceMotion
                  ? { duration: 0.15 }
                  : { type: "spring", stiffness: 140, damping: 18 }
              }
              onAnimationComplete={finishSelection}
            >
              <ChapterCard3D
                chapter={selected}
                progress={progressById[selected.id] ?? 0}
                active
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
