import { memo, useRef, useState } from "react";
import { motion } from "motion/react";
import { ArrowRight, Clock } from "lucide-react";
import type { CarouselChapter } from "@/types/chapter";
import { cn } from "@/lib/utils";
import { usePerfMode, useRafThrottle } from "@/hooks/use-perf-mode";

type ChapterCard3DProps = {
  chapter: CarouselChapter;
  progress: number;
  active?: boolean;
  className?: string;
};

function ChapterCard3DBase({ chapter, progress, active, className }: ChapterCard3DProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const Icon = chapter.icon;
  const { lite } = usePerfMode();

  // Pointer events fire far faster than the display refresh; coalesce to one per frame.
  const onMove = useRafThrottle((clientX: number, clientY: number) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (clientX - r.left) / r.width - 0.5;
    const py = (clientY - r.top) / r.height - 0.5;
    setTilt({ x: -py * 12, y: px * 14 });
  });

  return (
    <motion.div
      ref={ref}
      onPointerMove={lite ? undefined : (e) => onMove(e.clientX, e.clientY)}
      onPointerLeave={lite ? undefined : () => setTilt({ x: 0, y: 0 })}
      animate={lite ? undefined : { rotateX: tilt.x, rotateY: tilt.y }}
      transition={{ type: "spring", stiffness: 200, damping: 18 }}
      style={{ transformStyle: "preserve-3d" }}
      className={cn(
        "glass-card group/card relative flex h-full w-full flex-col overflow-hidden rounded-2xl p-5 text-left transition-shadow duration-300",
        active && "glow-crystal",
        className,
      )}
    >
      {/* glass sheen — skipped on low-end devices */}
      {!lite && (
        <span className="pointer-events-none absolute inset-0 z-20 overflow-hidden rounded-2xl">
          <span className="absolute -inset-y-10 -left-1/3 w-1/3 rotate-12 bg-gradient-to-r from-transparent via-foreground/12 to-transparent opacity-0 transition-opacity duration-300 group-hover/card:animate-sheen group-hover/card:opacity-100" />
        </span>
      )}
      <div
        className={cn(
          "pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-primary/20",
          lite ? "opacity-40" : "blur-3xl",
        )}
      />

      <div className="relative flex items-start justify-between">
        {/* premium 3D icon */}
        <div className="relative h-14 w-14" style={{ transform: "translateZ(40px)" }}>
          <div className="absolute inset-0 rounded-2xl bg-primary/25 blur-lg" />
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-crystal-glow/40 to-primary/5 ring-1 ring-primary/40" />
          <div className="absolute inset-[3px] rounded-xl bg-gradient-to-b from-background/60 to-background/10 ring-1 ring-border" />
          <Icon className="absolute inset-0 m-auto h-6 w-6 text-primary" />
        </div>
        <div className="flex flex-col items-end gap-2">
          <span className="font-mono text-xs text-muted-foreground">
            {String(chapter.id).padStart(2, "0")}
          </span>
          <span className="rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 font-bangla text-[10px] text-primary">
            {chapter.difficulty}
          </span>
        </div>
      </div>

      <h3
        className="relative mt-4 font-bangla text-lg font-semibold leading-snug"
        style={{ transform: "translateZ(24px)" }}
      >
        {chapter.title}
      </h3>
      <p className="relative mt-1 text-xs uppercase tracking-widest text-primary/80">
        {chapter.subtitle}
      </p>
      <p className="relative mt-3 font-bangla text-sm text-muted-foreground">
        {chapter.description}
      </p>

      <div className="relative mt-auto pt-5">
        <div className="flex items-center justify-between text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3 w-3" /> {chapter.timeEstimate}
          </span>
          <span>{progress}%</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary to-crystal-glow transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 font-bangla text-sm font-semibold text-primary-foreground transition-transform group-hover/card:scale-[1.02]">
          পড়া শুরু করুন
          <ArrowRight className="h-4 w-4" />
        </div>
      </div>
    </motion.div>
  );
}

export const ChapterCard3D = memo(ChapterCard3DBase);
