import { FileText, Calculator, ShieldCheck, Globe2, ExternalLink, Download } from "lucide-react";

const resources = [
  {
    id: "textbook",
    title: "ICT Textbook PDF",
    bangla: "আইসিটি পাঠ্যবই",
    description: "Download the official NCTB ICT textbook for secondary level.",
    href: "http://www.nctb.gov.bd/",
    icon: FileText,
    external: true,
  },
  {
    id: "formulas",
    title: "Formula Sheet",
    bangla: "সূত্র শীট",
    description: "Quick reference for Excel formulas, percentages, and product calculations.",
    href: "#resources",
    icon: Calculator,
    external: false,
  },
  {
    id: "safety",
    title: "Cyber Safety Checklist",
    bangla: "সাইবার নিরাপত্তা চেকলিস্ট",
    description: "2FA, malware defense, and safe browsing habits in one page.",
    href: "https://sscchapter2ict.lovable.app",
    icon: ShieldCheck,
    external: true,
  },
  {
    id: "nctb",
    title: "NCTB Website",
    bangla: "এনসিটিবি ওয়েবসাইট",
    description: "Visit the National Curriculum and Textbook Board portal.",
    href: "http://www.nctb.gov.bd/",
    icon: Globe2,
    external: true,
  },
];

export function ResourceHub() {
  return (
    <section id="resources" className="mx-auto max-w-7xl px-6 py-16 md:py-24">
      <div className="mb-10 text-center md:text-left">
        <div className="text-xs uppercase tracking-widest text-primary">Resources</div>
        <h2 className="mt-2 font-bangla text-3xl font-bold md:text-4xl">সহায়ক উপাদান</h2>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">
          Everything you need to study smarter — official books, formula sheets, and safety guides.
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {resources.map((r) => {
          const Icon = r.icon;
          const Tag: any = r.href ? "a" : "button";
          const tagProps = r.href
            ? { href: r.href, target: r.external ? "_blank" : undefined, rel: r.external ? "noreferrer" : undefined }
            : { type: "button" };
          return (
            <Tag
              key={r.id}
              {...tagProps}
              className="glass-card group relative block overflow-hidden rounded-2xl p-6 text-left transition-all hover:-translate-y-1 hover:glow-crystal focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <div className="absolute -right-12 -top-12 h-32 w-32 rounded-full bg-primary/10 opacity-50 blur-2xl transition-opacity group-hover:opacity-100" />
              <div className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="relative mt-4 font-bangla text-lg font-semibold leading-snug">{r.bangla}</h3>
              <p className="relative mt-0.5 text-sm font-medium text-foreground/90">{r.title}</p>
              <p className="relative mt-2 text-sm text-muted-foreground">{r.description}</p>
              <div className="relative mt-5 inline-flex items-center gap-1.5 text-sm text-primary">
                <span>{r.external ? "Open resource" : "View sheet"}</span>
                {r.external ? (
                  <ExternalLink className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                ) : (
                  <Download className="h-3.5 w-3.5" />
                )}
              </div>
            </Tag>
          );
        })}
      </div>
    </section>
  );
}
