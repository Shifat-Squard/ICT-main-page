import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useReducedMotion, motion } from "motion/react";
import confetti from "canvas-confetti";
import {
  Globe2,
  ShieldCheck,
  Wifi,
  FileSpreadsheet,
  Palette,
  Code2,
  Download,
  ExternalLink,
  ArrowRight,
  Check,
} from "lucide-react";
import { TextScramble } from "@/components/ui/text-scramble";
import { ShaderBackground } from "@/components/ShaderBackground";
import { usePerfMode } from "@/hooks/use-perf-mode";
import { Zap, ZapOff } from "lucide-react";
import { ThreeDChapterCarousel } from "@/components/ThreeDChapterCarousel";
import { ResourceHub } from "@/components/ResourceHub";
import { HeroDelight, HeroEntrance } from "@/components/HeroDelight";
import type { CarouselChapter } from "@/types/chapter";
import ch1Img from "@/assets/ch1.jpg";
import ch2Img from "@/assets/ch2.jpg";
import ch3Img from "@/assets/ch3.jpg";
import ch4Img from "@/assets/ch4.jpg";
import ch5Img from "@/assets/ch5.jpg";
import ch6Img from "@/assets/ch6.jpg";

export const Route = createFileRoute("/")({
  component: CourseHub,
});

type Chapter = CarouselChapter & {
  topics: string[];
  highlight: string;
  image: string;
};


const chapters: Chapter[] = [
  {
    id: 1,
    title: "তথ্য ও যোগাযোগ প্রযুক্তি ও আমাদের বাংলাদেশ",
    subtitle: "ICT and Our Bangladesh",
    icon: Globe2,
    description: "ই-সেবা, ই-গভর্ন্যান্স ও ডিজিটাল বাংলাদেশের অগ্রযাত্রা।",
    difficulty: "সহজ",
    timeEstimate: "৪৫ মিনিট",
    topics: ["E-Services", "E-Governance", "Bangabandhu Satellite-1"],
    highlight: "Bangladesh — the 57th country to launch a satellite.",
    href: "https://chapter1ict.lovable.app",
    image: ch1Img,
  },
  {
    id: 2,
    title: "কম্পিউটার রক্ষণাবেক্ষণ ও সাইবার নিরাপত্তা",
    subtitle: "Maintenance & Cyber Security",
    icon: ShieldCheck,
    description: "ট্রাবলশুটিং, ম্যালওয়্যার প্রতিরোধ ও সাইবার নৈতিকতা।",
    difficulty: "মাধ্যম",
    timeEstimate: "৫০ মিনিট",
    topics: ["Troubleshooting", "Malware Defense", "Cyber Ethics"],
    highlight: "Two-Factor Authentication (2FA) as a security baseline.",
    href: "https://sscchapter2ict.lovable.app",
    image: ch2Img,
  },
  {
    id: 3,
    title: "ইন্টারনেট ও ওয়েব পরিচিতি",
    subtitle: "Internet & Web Introduction",
    icon: Wifi,
    description: "ডিজিটাল কনটেন্ট, ই-বুক ও ওয়েব ব্রাউজিংয়ের মূল ধারণা।",
    difficulty: "সহজ",
    timeEstimate: "৪০ মিনিট",
    topics: ["Digital Content", "E-books", "Web Browsing"],
    highlight: "5 types of e-books · Website vs. Web Portal.",
    href: "https://chapter3ict.lovable.app",
    image: ch3Img,
  },
  {
    id: 4,
    title: "আমার লেখালেখি ও হিসাব",
    subtitle: "Writing & Calculation",
    icon: FileSpreadsheet,
    description: "ওয়ার্ড প্রসেসিং ও স্প্রেডশিটে হিসাব-নিকাশের কৌশল।",
    difficulty: "মাধ্যম",
    timeEstimate: "৬০ মিনিট",
    topics: ["Word Processing", "Spreadsheets", "Excel Analysis"],
    highlight: "Formulas like =PRODUCT and percentage calculations.",
    href: "https://chapter4ict.lovable.app",
    image: ch4Img,
  },
  {
    id: 5,
    title: "মাল্টিমিডিয়া ও গ্রাফিক্স",
    subtitle: "Multimedia & Graphics",
    icon: Palette,
    description: "প্রেজেন্টেশন, ফটোশপ লেয়ার ও ভেক্টর গ্রাফিক্সের জগৎ।",
    difficulty: "মাধ্যম",
    timeEstimate: "৫৫ মিনিট",
    topics: ["PowerPoint", "Photoshop Layers", "Illustrator Vectors"],
    highlight: "Multimedia elements — Text, Audio, Video, VFX.",
    href: "https://chapter5ictssc.lovable.app",
    image: ch5Img,
  },
  {
    id: 6,
    title: "প্রোগ্রামিংয়ের মাধ্যমে সমস্যার সমাধান",
    subtitle: "Solving Problems through Programming",
    icon: Code2,
    description: "পাইথন দিয়ে ভেরিয়েবল, লজিক ও লুপে সমস্যা সমাধান।",
    difficulty: "কঠিন",
    timeEstimate: "৭৫ মিনিট",
    topics: ["Python", "Variables", "Logic & Loops"],
    highlight: "Basic data types — int, float, str.",
    href: "https://chapter6ict.lovable.app",
    image: ch6Img,
  },
];



function CourseHub() {
  const { lite, toggle: toggleLite } = usePerfMode();
  const prefersReduced = useReducedMotion();
  const reduce = prefersReduced || lite;
  const [completed, setCompleted] = useState<Set<number>>(new Set());
  const progress = Math.round((completed.size / chapters.length) * 100);
  const [poppedId, setPoppedId] = useState<number | null>(null);
  const celebrated = useRef(false);

  const toggle = (id: number) => {
    setCompleted((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
    setPoppedId(id);
    setTimeout(() => setPoppedId(null), 260);
  };

  useEffect(() => {
    if (progress === 100 && !celebrated.current && !reduce) {
      celebrated.current = true;
      const end = Date.now() + 800;
      const frame = () => {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ["#A7D8DE", "#00E5FF", "#EAFDFF"],
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ["#A7D8DE", "#00E5FF", "#EAFDFF"],
        });
        if (Date.now() < end) requestAnimationFrame(frame);
      };
      requestAnimationFrame(frame);
    }
    if (progress < 100) celebrated.current = false;
  }, [progress, reduce]);

  const orbitBadges = chapters.map((ch, i) => ({
    id: ch.id,
    label: String(ch.id).padStart(2, "0"),
    icon: ch.icon,
    href: `#chapter-${ch.id}`,
    angle: i * (360 / chapters.length),
    radius: i % 2 === 0 ? "170px" : "210px",
    duration: i % 2 === 0 ? "28s" : "36s",
  }));

  return (
    <div className="relative min-h-screen text-foreground">
      <ShaderBackground />
      {/* NAV */}
      <header className="sticky top-0 z-40 border-b border-border/40 bg-background/40 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 ring-1 ring-primary/30">
              <div className={`absolute inset-0 rounded-lg bg-primary/20 blur-md ${lite ? "" : "animate-pulse-glow"}`} />
              <Globe2 className="relative h-5 w-5 text-primary" />
            </div>
            <div className="leading-tight">
              <div className="text-sm font-semibold tracking-tight">ICT Course Hub</div>
              <div className="font-bangla text-xs text-muted-foreground">মাধ্যমিক আইসিটি</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
              <a href="#chapters" className="hover:text-foreground transition-colors">Chapters</a>
              <a href="#progress" className="hover:text-foreground transition-colors">Progress</a>
              <a href="#resources" className="hover:text-foreground transition-colors">Resources</a>
            </nav>
            <button
              type="button"
              onClick={toggleLite}
              aria-pressed={lite}
              title={lite ? "Lite mode on — animations reduced" : "Lite mode off — full animations"}
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/40 px-3 py-1.5 text-xs text-muted-foreground backdrop-blur transition-colors hover:text-foreground"
            >
              {lite ? <ZapOff className="h-3.5 w-3.5" /> : <Zap className="h-3.5 w-3.5 text-primary" />}
              <span className="hidden sm:inline">{lite ? "Lite mode" : "Full motion"}</span>
            </button>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-6 py-20 md:py-28">
          <div className="grid gap-12 md:grid-cols-2 md:items-center">
            <div>
              <HeroEntrance delay={0} lite={lite}>
                <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/40 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
                  <span className={`h-1.5 w-1.5 rounded-full bg-primary ${lite ? "" : "animate-pulse-glow"}`} />
                  Secondary Curriculum · 6 Chapters
                </div>
              </HeroEntrance>

              <HeroEntrance delay={0.1} lite={lite}>
                <TextScramble
                  as="div"
                  trigger={!lite}
                  className="mt-6 font-display text-sm font-medium uppercase tracking-[0.3em] text-crystal-gradient"
                  duration={1.4}
                  speed={0.035}
                >
                  Information · Communication · Technology
                </TextScramble>
              </HeroEntrance>

              <HeroEntrance delay={0.2} lite={lite}>
                <h1 className="mt-3 font-bangla text-4xl font-bold leading-tight md:text-6xl">
                  <span className="text-crystal-gradient">তথ্য ও যোগাযোগ</span>
                  <br />
                  <span className="text-foreground">প্রযুক্তি</span>
                </h1>
              </HeroEntrance>

              <HeroEntrance delay={0.3} lite={lite}>
                <p className="mt-6 max-w-lg text-lg text-muted-foreground">
                  Knowledge is the wealth of the 21st century. Explore the full Bangla ICT
                  curriculum through six interactive chapters — from e-governance to Python.
                </p>
              </HeroEntrance>

              <HeroEntrance delay={0.4} lite={lite}>
                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <a
                    href="#chapters"
                    className="group inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-all hover:glow-crystal"
                  >
                    Start Learning
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  </a>
                  <a
                    href="#resources"
                    className="inline-flex items-center gap-2 rounded-lg border border-border bg-card/40 px-5 py-3 text-sm font-medium text-foreground backdrop-blur transition-colors hover:bg-card/60"
                  >
                    <Download className="h-4 w-4" />
                    Download PDF
                  </a>
                </div>
              </HeroEntrance>
            </div>

            {/* Animated globe */}
            <HeroEntrance delay={0.25} lite={lite}>
              <div className="relative mx-auto flex h-80 w-80 items-center justify-center md:h-96 md:w-96">
                <HeroDelight badges={orbitBadges} lite={lite} />
                <div className={`absolute inset-0 rounded-full bg-primary/10 ${lite ? "" : "blur-3xl animate-pulse-glow"}`} />
                <svg
                  viewBox="0 0 400 400"
                  className={`relative h-full w-full ${lite ? "" : "animate-spin-slow"}`}
                  aria-hidden
                >
                  <defs>
                    <radialGradient id="g" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="oklch(0.86 0.06 210)" stopOpacity="0.25" />
                      <stop offset="70%" stopColor="oklch(0.3 0.15 265)" stopOpacity="0.15" />
                      <stop offset="100%" stopColor="transparent" />
                    </radialGradient>
                  </defs>
                  <circle cx="200" cy="200" r="180" fill="url(#g)" />
                  <circle cx="200" cy="200" r="180" fill="none" stroke="oklch(0.86 0.06 210 / 0.4)" strokeWidth="1" />
                  {[...Array(8)].map((_, i) => (
                    <ellipse
                      key={i}
                      cx="200"
                      cy="200"
                      rx="180"
                      ry={180 - i * 22}
                      fill="none"
                      stroke="oklch(0.86 0.06 210 / 0.25)"
                      strokeWidth="0.8"
                    />
                  ))}
                  {[...Array(6)].map((_, i) => (
                    <ellipse
                      key={`v${i}`}
                      cx="200"
                      cy="200"
                      rx={180 - i * 30}
                      ry="180"
                      fill="none"
                      stroke="oklch(0.86 0.06 210 / 0.2)"
                      strokeWidth="0.8"
                    />
                  ))}
                  {[
                    [140, 120], [260, 150], [180, 240], [280, 260], [120, 200], [220, 90],
                  ].map(([cx, cy], i) => (
                    <circle key={i} cx={cx} cy={cy} r="3" fill="oklch(0.92 0.08 210)">
                      {!lite && (
                        <animate attributeName="opacity" values="0.3;1;0.3" dur={`${2 + i * 0.4}s`} repeatCount="indefinite" />
                      )}
                    </circle>
                  ))}
                </svg>
              </div>
            </HeroEntrance>
          </div>
        </div>
      </section>

      {/* 3D CAROUSEL */}
      <section className="mx-auto max-w-7xl px-6 pb-8">
        <div className="mb-6 text-center">
          <div className="text-xs uppercase tracking-widest text-primary">Explore in 3D</div>
          <h2 className="mt-2 font-bangla text-3xl font-bold md:text-4xl">অধ্যায় ঘুরে দেখুন</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Drag or swipe to spin · click a card to open the chapter
          </p>
        </div>
        <ThreeDChapterCarousel
          chapters={chapters}
          progressById={Object.fromEntries(
            chapters.map((c) => [c.id, completed.has(c.id) ? 100 : 0]),
          )}
        />
      </section>


      {/* PROGRESS */}
      <section id="progress" className="mx-auto max-w-7xl px-6">
        <div className="glass-card rounded-2xl p-6 md:p-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground">Your Progress</div>
              <div className="mt-1 text-2xl font-semibold">
                {completed.size} <span className="text-muted-foreground">/ {chapters.length} chapters</span>
              </div>
            </div>
            <div className="text-4xl font-bold text-crystal-gradient">{progress}%</div>
          </div>
          <div className="mt-5 h-2 overflow-hidden rounded-full bg-muted">
            <div
              className={`h-full rounded-full bg-gradient-to-r from-primary to-crystal-glow transition-all duration-500 ${progress === 100 ? "animate-progress-shimmer" : ""}`}
              style={{ width: `${progress}%` }}
            />
          </div>
          {progress === 100 && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 rounded-lg border border-primary/30 bg-primary/10 px-4 py-3 text-center font-bangla text-sm text-primary"
            >
              অভিনন্দন! সব অধ্যায় সম্পূর্ণ হয়েছে 🎉
            </motion.div>
          )}
        </div>
      </section>

      {/* CHAPTERS */}
      <section id="chapters" className="mx-auto max-w-7xl px-6 py-16 md:py-24">
        <div className="mb-10 flex items-end justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-primary">Chapters</div>
            <h2 className="mt-2 font-bangla text-3xl font-bold md:text-4xl">অধ্যায়সমূহ</h2>
          </div>
          <div className="hidden text-sm text-muted-foreground md:block">Click a chapter to mark complete</div>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {chapters.map((ch) => {
            const Icon = ch.icon;
            const done = completed.has(ch.id);
            const Tag: any = ch.href ? "a" : "button";
            const tagProps = ch.href
              ? { href: ch.href, target: "_blank", rel: "noreferrer" }
              : { type: "button", onClick: () => toggle(ch.id) };
            return (
              <Tag
                key={ch.id}
                id={`chapter-${ch.id}`}
                {...tagProps}
                className="glass-card group relative block overflow-hidden rounded-2xl text-left transition-all hover:-translate-y-1 hover:glow-crystal focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <div className="relative h-40 overflow-hidden">
                  <img
                    src={ch.image}
                    alt={ch.subtitle}
                    loading="lazy"
                    width={1024}
                    height={1024}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
                </div>
                <div className="relative p-6">
                <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-primary/10 blur-3xl transition-opacity group-hover:opacity-100 opacity-50" />


                <div className="relative flex items-start justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-muted-foreground">
                      {String(ch.id).padStart(2, "0")}
                    </span>
                    <button
                      type="button"
                      aria-label={done ? "Mark incomplete" : "Mark complete"}
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        toggle(ch.id);
                      }}
                      className={`flex h-6 w-6 items-center justify-center rounded-full border transition-all ${
                        done
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-transparent"
                      } ${poppedId === ch.id ? "animate-pop" : ""}`}
                    >
                      {done && <Check className="h-3.5 w-3.5" strokeWidth={3} />}
                    </button>
                  </div>
                </div>

                <h3 className="relative mt-5 font-bangla text-xl font-semibold leading-snug">
                  {ch.title}
                </h3>
                <p className="relative mt-1 text-sm text-muted-foreground">{ch.subtitle}</p>

                <div className="relative mt-5">
                  <div className="text-[10px] uppercase tracking-widest text-primary/80">Key Topics</div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {ch.topics.map((t) => (
                      <span
                        key={t}
                        className="rounded-md border border-border bg-background/40 px-2 py-1 text-xs text-foreground/90"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <p className="relative mt-5 border-t border-border/60 pt-4 text-sm text-muted-foreground">
                  {ch.highlight}
                </p>

                <div className="relative mt-5 flex items-center justify-between text-sm">
                  <span className="text-primary">{ch.href ? "Open chapter →" : "Open chapter"}</span>
                  <ArrowRight className="h-4 w-4 text-primary transition-transform group-hover:translate-x-1" />
                </div>
                </div>
              </Tag>
            );
          })}
        </div>
      </section>

      <ResourceHub />

      {/* FOOTER */}
      <footer className="border-t border-border/40 bg-background/40 backdrop-blur-xl">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 ring-1 ring-primary/30">
                <Globe2 className="h-5 w-5 text-primary" />
              </div>
              <div className="text-sm font-semibold">ICT Course Hub</div>
            </div>
            <p className="mt-4 max-w-xs text-sm text-muted-foreground">
              A study companion for the Bangla secondary ICT curriculum.
            </p>
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest text-primary">Resources</div>
            <ul className="mt-4 space-y-2 text-sm">
              <li>
                <a
                  href="http://www.nctb.gov.bd/"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 text-foreground/90 hover:text-primary"
                >
                  NCTB Website <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </li>
              <li>
                <a
                  href="#resources"
                  className="inline-flex items-center gap-2 text-foreground/90 hover:text-primary"
                >
                  <Download className="h-3.5 w-3.5" /> Download ICT Textbook (PDF)
                </a>
              </li>
            </ul>
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest text-primary">Curriculum</div>
            <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
              <li>6 chapters · Bangla medium</li>
              <li>Interactive progress tracking</li>
              <li>Aligned with the national textbook</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border/40 py-5 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} ICT Course Hub · Built for learners of Bangladesh
        </div>
      </footer>
    </div>
  );
}
