import type { LucideIcon } from "lucide-react";

export type Difficulty = "সহজ" | "মাধ্যম" | "কঠিন";

export type CarouselChapter = {
  id: number;
  title: string;
  subtitle: string;
  icon: LucideIcon;
  description: string;
  difficulty: Difficulty;
  timeEstimate: string;
  href?: string;
};
