import { useCallback, useEffect, useRef, useSyncExternalStore } from "react";

const STORAGE_KEY = "ict-lite-mode";

const listeners = new Set<() => void>();
let liteMode: boolean | null = null;

function detectLowEnd() {
  if (typeof window === "undefined") return false;
  const nav = navigator as Navigator & { deviceMemory?: number; connection?: { saveData?: boolean } };
  const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
  const lowCores = (nav.hardwareConcurrency ?? 8) <= 4;
  const lowMemory = (nav.deviceMemory ?? 8) <= 4;
  const saveData = nav.connection?.saveData === true;
  return reduced || saveData || lowCores || lowMemory;
}

function read(): boolean {
  if (liteMode !== null) return liteMode;
  if (typeof window === "undefined") return false;
  const stored = window.localStorage.getItem(STORAGE_KEY);
  liteMode = stored === null ? detectLowEnd() : stored === "1";
  return liteMode;
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export function setLiteMode(next: boolean) {
  liteMode = next;
  try {
    window.localStorage.setItem(STORAGE_KEY, next ? "1" : "0");
  } catch {
    /* storage unavailable */
  }
  listeners.forEach((l) => l());
}

/**
 * Performance mode for low-end devices.
 * Auto-detects prefers-reduced-motion / low cores / low memory / save-data,
 * and can be toggled manually (persisted in localStorage).
 */
export function usePerfMode() {
  const lite = useSyncExternalStore(
    subscribe,
    read,
    () => false, // SSR: assume full motion, corrected on hydration
  );
  const toggle = useCallback(() => setLiteMode(!read()), []);
  return { lite, setLite: setLiteMode, toggle };
}

/** rAF-throttled callback: coalesces high-frequency pointer events to one per frame. */
export function useRafThrottle<T extends unknown[]>(fn: (...args: T) => void) {
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const frame = useRef(0);
  const args = useRef<T | null>(null);

  useEffect(
    () => () => {
      if (frame.current) cancelAnimationFrame(frame.current);
    },
    [],
  );

  return useCallback((...next: T) => {
    args.current = next;
    if (frame.current) return;
    frame.current = requestAnimationFrame(() => {
      frame.current = 0;
      if (args.current) fnRef.current(...args.current);
    });
  }, []);
}
